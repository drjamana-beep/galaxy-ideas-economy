#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# new-planet.sh — مولّد كوكب جديد من القالب الموحّد
# ────────────────────────────────────────────────────────────────
# الاستخدام:
#   pnpm new:planet p15-energy "الطاقة" "⚡" "#FBBF24"
# ════════════════════════════════════════════════════════════════
set -euo pipefail

ID="${1:?يجب تمرير معرّف الكوكب، مثل p15-energy}"
NAME="${2:?يجب تمرير اسم الكوكب، مثل الطاقة}"
ICON="${3:-🪐}"
COLOR="${4:-#8B5CF6}"

DIR="planets/${ID}"

if [ -d "$DIR" ]; then
  echo "❌ الكوكب ${ID} موجود مسبقاً."
  exit 1
fi

mkdir -p "${DIR}/src/ui" "${DIR}/tests"

# manifest.json — العقد الموحّد لكل كوكب
cat > "${DIR}/manifest.json" << EOF
{
  "id": "${ID}",
  "name": "${NAME}",
  "icon": "${ICON}",
  "color": "${COLOR}",
  "version": "0.1.0",
  "route": "/planets/${ID#p*-}",
  "protocols": ["surplus-redistribution"]
}
EOF

# package.json
cat > "${DIR}/package.json" << EOF
{
  "name": "@galaxy/planet-${ID}",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "main": "src/api.js",
  "scripts": { "lint": "eslint .", "build": "echo ok", "test": "echo 'add tests'", "clean": "rm -rf .turbo" },
  "dependencies": { "@galaxy/core": "workspace:*", "@galaxy/types": "workspace:*" }
}
EOF

# api.js — واجهة الكوكب البرمجية
cat > "${DIR}/src/api.js" << EOF
/** ${NAME} (${ICON}) — واجهة الكوكب البرمجية */
import manifest from '../manifest.json' assert { type: 'json' };

export const planet = manifest;

/** يلتزم الكوكب ببروتوكول إعادة توزيع الفائض */
export async function reportSurplus(resource) {
  // TODO: تنفيذ المنطق الخاص بـ ${NAME}
  return { planet: manifest.id, resource };
}
EOF

cat > "${DIR}/README.md" << EOF
# ${ICON} ${NAME}

كوكب ضمن مجرة اقتصاد الأفكار.

- **المعرّف:** \`${ID}\`
- **اللون:** \`${COLOR}\`
- **البروتوكولات:** إعادة توزيع الفائض
EOF

echo "✅ تم إنشاء الكوكب: ${ICON} ${NAME} (${ID})"
echo "   📁 ${DIR}"
echo ""
echo "الخطوة التالية: أضف الكوكب إلى packages/ui/components/GalaxyMap/planets.data.js"
