/**
 * planets.data.js
 * ─────────────────────────────────────────────────────────────
 * المصدر الوحيد للحقيقة (Single Source of Truth) لكواكب المجرة.
 * أي تطبيق أو كوكب في الـ Monorepo يستورد من هنا فقط.
 *
 * البنية متوافقة مع manifest.json لكل كوكب في planets/p0X-name/
 * ─────────────────────────────────────────────────────────────
 */

/** @typedef {Object} Planet
 *  @property {string} id        معرّف فريد متوافق مع مجلد الكوكب
 *  @property {string} icon      الإيموجي التمثيلي
 *  @property {string} name      الاسم المعروض
 *  @property {string} color     اللون الأساسي (hex)
 *  @property {string} route     مسار الكوكب في التطبيق
 */

/** النواة المركزية للمجرة */
export const GALAXY_CORE = {
  id: 'p01-ideas-economy',
  icon: '💡',
  name: 'اقتصاد الأفكار',
  color: '#F5C842',
  route: '/planets/ideas-economy',
};

/** الكواكب الـ13 المحيطة (النواة منفصلة في المركز) */
export const ORBITING_PLANETS = [
  { id: 'p02-academy',     icon: '🎓', name: 'الأكاديمية',   color: '#06B6D4', route: '/planets/academy' },
  { id: 'p03-giving',      icon: '🌍', name: 'واجهة العطاء', color: '#10B981', route: '/planets/giving' },
  { id: 'p04-thought',     icon: '🧠', name: 'الفكر',        color: '#EC4899', route: '/planets/thought' },
  { id: 'p05-spirit',      icon: '🕊️', name: 'الروح',        color: '#A78BFA', route: '/planets/spirit' },
  { id: 'p06-sciences',    icon: '🔬', name: 'العلوم',       color: '#22D3EE', route: '/planets/sciences' },
  { id: 'p07-environment', icon: '🌱', name: 'البيئة',       color: '#84CC16', route: '/planets/environment' },
  { id: 'p08-industry',    icon: '🏭', name: 'الصناعة',      color: '#F97316', route: '/planets/industry' },
  { id: 'p09-work',        icon: '💼', name: 'العمل',        color: '#FCD34D', route: '/planets/work' },
  { id: 'p10-care',        icon: '👵', name: 'الرعاية',      color: '#F472B6', route: '/planets/care' },
  { id: 'p11-protection',  icon: '🛡️', name: 'الحماية',      color: '#6366F1', route: '/planets/protection' },
  { id: 'p12-relief',      icon: '🚨', name: 'الإغاثة',      color: '#EF4444', route: '/planets/relief' },
  { id: 'p13-medicine',    icon: '🩺', name: 'الطب',         color: '#14B8A6', route: '/planets/medicine' },
  { id: 'p14-arts',        icon: '🎨', name: 'الفنون',       color: '#C084FC', route: '/planets/arts' },
];

/** كل الكواكب الـ14 معاً (للاستخدامات التي تحتاج القائمة الكاملة) */
export const ALL_PLANETS = [GALAXY_CORE, ...ORBITING_PLANETS];
