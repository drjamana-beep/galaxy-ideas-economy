# GalaxyMap — خريطة المجرة التفاعلية

مكوّن خريطة المجرة الدائرية: نواة مركزية (الكوكب الأم «اقتصاد الأفكار») تحيط بها 13 كوكباً في حلقة فلكية متناغمة.

## الملفات

| الملف | الدور |
|---|---|
| `planets.data.js` | المصدر الوحيد للحقيقة — بيانات الكواكب الـ14 |
| `GalaxyMap.css`   | الأنماط (معزولة بـ `galaxy-map__` و `gm-`) |
| `GalaxyMap.jsx`   | مكوّن React |
| `index.js`        | نقطة التصدير |

## الاستخدام في React (داخل `apps/`)

```jsx
import { GalaxyMap } from '@galaxy/ui/GalaxyMap';
import { useRouter } from 'next/navigation';

export default function GalaxyPage() {
  const router = useRouter();
  return (
    <GalaxyMap
      onPlanetClick={(planet) => router.push(planet.route)}
      onCoreClick={() => console.log('تم النقر على الكوكب الأم')}
      showHint
    />
  );
}
```

## الخصائص (Props)

| الخاصية | النوع | الافتراضي | الوصف |
|---|---|---|---|
| `onPlanetClick` | `(planet) => void` | — | يُستدعى عند النقر على كوكب؛ إن مرّرته يُلغى التوجيه الافتراضي ليتولّى الـ router |
| `onCoreClick`   | `() => void` | — | يُستدعى عند النقر على النواة (بالإضافة لتثبيت بطاقة الفلسفة) |
| `showHint`      | `boolean` | `true` | إظهار سطر التلميح أسفل الخريطة |

## المبدأ الهندسي

كل كوكب يُوضع رياضياً عبر متغير `--angle`:

```css
transform: rotate(var(--angle)) translate(var(--gm-radius)) rotate(calc(-1 * var(--angle)));
```

دوران بزاوية الكوكب → دفع للخارج بنصف القطر → دوران عكسي ليبقى الكوكب قائماً.
كل الأبعاد بـ `clamp()` فالخريطة متجاوبة تماماً دون أي JavaScript للتموضع.

## تخصيص الثيم

يرث المكوّن متغيرات الـ Design Tokens إن وُجدت (`--f-body`, `--f-display`, `--t-secondary`).
لتعديل الأبعاد، اضبط المتغيرات على `.galaxy-map`:

```css
.galaxy-map { --gm-size: 500px; --gm-planet: 60px; }
```

## إضافة كوكب أو تعديله

عدّل `planets.data.js` فقط — كل الواجهات تتحدّث تلقائياً.
لا تعدّل المواضع يدوياً؛ الزوايا تُحسب آلياً من طول المصفوفة.
