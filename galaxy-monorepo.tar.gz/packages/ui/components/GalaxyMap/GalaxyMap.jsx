/**
 * GalaxyMap.jsx — مكوّن خريطة المجرة التفاعلية (React)
 * ════════════════════════════════════════════════════════════════
 * يُستخدم داخل apps/ في الـ Monorepo:
 *   import { GalaxyMap } from '@galaxy/ui/GalaxyMap';
 *   <GalaxyMap onPlanetClick={(p) => router.push(p.route)} />
 *
 * المبدأ الهندسي نفسه المُستخدم في النسخة الثابتة:
 * كل كوكب يُوضع بـ rotate(angle) → translate(radius) → rotate(-angle)
 * عبر متغير CSS ‎--angle‎، فيعمل دون JavaScript للتموضع، والـ React
 * يضيف فقط التفاعل والتوجيه (routing).
 *
 * المتطلبات: استيراد GalaxyMap.css في نقطة دخول التطبيق أو هنا.
 * ════════════════════════════════════════════════════════════════
 */

import { useState, useCallback } from 'react';
import { GALAXY_CORE, ORBITING_PLANETS } from './planets.data.js';
import './GalaxyMap.css';

/** يحسب زاوية الكوكب بالتساوي حول الدائرة، يبدأ من الأعلى (-90°). */
function angleFor(index, total) {
  return `${-90 + index * (360 / total)}deg`;
}

/**
 * @typedef {Object} GalaxyMapProps
 * @property {(planet: object) => void} [onPlanetClick]  عند النقر على كوكب
 * @property {() => void} [onCoreClick]                  عند النقر على النواة
 * @property {boolean} [showHint]                        إظهار سطر التلميح
 */

/** كوكب مداري واحد */
function Planet({ planet, angle, onClick }) {
  const style = {
    '--angle': angle,
    '--planet-color': planet.color,
  };
  return (
    <li className="galaxy-map__planet" style={style}>
      <a
        className="galaxy-map__planet-btn"
        href={planet.route}
        aria-label={planet.name}
        data-planet-id={planet.id}
        onClick={(e) => {
          if (onClick) {
            e.preventDefault();
            onClick(planet);
          }
        }}
      >
        <span aria-hidden="true">{planet.icon}</span>
        <span className="galaxy-map__planet-name">{planet.name}</span>
      </a>
    </li>
  );
}

/** بطاقة فلسفة الكوكب الأم */
function CorePhilosophy({ pinned }) {
  return (
    <div
      className={`gm-core-philosophy${pinned ? ' gm-pinned' : ''}`}
      role="tooltip"
    >
      <span className="gm-cp-badge">الكوكب الـ14 — الكوكب الأم</span>
      <div className="gm-cp-icon" aria-hidden="true">{GALAXY_CORE.icon}</div>
      <div className="gm-cp-title">{GALAXY_CORE.name}</div>
      <div className="gm-cp-text">
        ليست النواة كوكباً بين الكواكب، بل هي <strong>الأم التي تحتضنها جميعاً</strong>.
        منها تنبثق الأفكار، وإليها يعود الفائض، وبها تتوازن الكواكب الـ13
        وتترابط في منظومة <strong>واحدة عادلة</strong>.
      </div>
      <div className="gm-cp-divider" />
      <div className="gm-cp-meta">«تحتوي، وتوازن، وتربط» 🌌</div>
    </div>
  );
}

/**
 * خريطة المجرة التفاعلية الكاملة.
 * @param {GalaxyMapProps} props
 */
export function GalaxyMap({ onPlanetClick, onCoreClick, showHint = true }) {
  const [pinned, setPinned] = useState(false);
  const total = ORBITING_PLANETS.length;

  const handleCore = useCallback(
    (e) => {
      e.preventDefault();
      setPinned((p) => !p);
      onCoreClick?.();
    },
    [onCoreClick]
  );

  return (
    <>
      <nav className="galaxy-map" aria-label="خريطة المجرة التفاعلية — 14 كوكباً">
        <div className="galaxy-map__orbit galaxy-map__orbit--outer" aria-hidden="true" />
        <div className="galaxy-map__orbit galaxy-map__orbit--inner" aria-hidden="true" />

        <a
          className="galaxy-map__core"
          href={GALAXY_CORE.route}
          aria-label={`${GALAXY_CORE.name} — الكوكب الأم، النواة المركزية`}
          onClick={handleCore}
        >
          <span aria-hidden="true">{GALAXY_CORE.icon}</span>
          <span className="galaxy-map__core-label">{GALAXY_CORE.name}</span>
        </a>

        <CorePhilosophy pinned={pinned} />

        <ul className="galaxy-map__ring">
          {ORBITING_PLANETS.map((planet, i) => (
            <Planet
              key={planet.id}
              planet={planet}
              angle={angleFor(i, total)}
              onClick={onPlanetClick}
            />
          ))}
        </ul>
      </nav>

      {showHint && (
        <p className="gm-hint">
          اضغط على النواة لتثبيت البطاقة · مرّر فوق أي كوكب لاكتشافه
        </p>
      )}
    </>
  );
}

export default GalaxyMap;
