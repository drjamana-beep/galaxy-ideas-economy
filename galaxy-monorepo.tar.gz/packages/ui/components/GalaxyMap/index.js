/**
 * index.js — نقطة التصدير لمكوّن GalaxyMap في packages/ui
 *
 * الاستخدام في أي تطبيق داخل الـ Monorepo:
 *   import { GalaxyMap, ALL_PLANETS } from '@galaxy/ui/GalaxyMap';
 */
export { GalaxyMap, default } from './GalaxyMap.jsx';
export {
  GALAXY_CORE,
  ORBITING_PLANETS,
  ALL_PLANETS,
} from './planets.data.js';
