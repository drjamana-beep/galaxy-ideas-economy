/**
 * @galaxy/firebase-client — تهيئة Firebase موحّدة لكل تطبيقات المجرة
 * ────────────────────────────────────────────────────────────────
 * مصدر واحد لإعداد Firebase: أي تطبيق يستورد منه فلا تكرار للإعداد.
 */
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const config = {
  apiKey: import.meta.env?.VITE_FB_API_KEY,
  authDomain: 'ideagalaxy-84cfc.firebaseapp.com',
  projectId: 'ideagalaxy-84cfc',
  storageBucket: 'ideagalaxy-84cfc.appspot.com',
};

export const app = initializeApp(config);
export const auth = getAuth(app);
export const db = getFirestore(app);
